package Ejercicio1;

public class Main {
    public static void main(String[] args) {
        HiloEj1 hilo = new HiloEj1();
        hilo.start();
    }
}
